<footer id="footer" class="footer bg-overlay">
      <div class="footer-main">
        <div class="container">
          <div class="row justify-content-between">
            <div class="col-lg-4 col-md-6 footer-widget footer-about">
              <h3 class="widget-title">About Us</h3>
                <?php if($footer && $footer->logo): ?>
                  <img loading="lazy" width="200px" class="footer-logo" src="<?php echo e(asset('storage/' . $footer->logo)); ?>" alt="Stonytrack">
                <?php else: ?>
                  <img loading="lazy" width="200px" class="footer-logo" src="<?php echo e(asset('assets/images/logo/logo-footer.png')); ?>" alt="Stonytrack">
                <?php endif; ?>
              <p>
              <?php echo e($footer->about_txt ?? ''); ?>

              </p>
              <div class="footer-social">
                <ul>
                  <li><a target="_blank" href="<?php echo e($header->facebook ?? '#'); ?>"
                          aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                  </li>
                  <li><a target="_blank" href="<?php echo e($header->linkedin ?? '#'); ?>"
                          aria-label="Linkedin"><i class="fab fa-linkedin"></i></a>
                  </li>
                  <li><a target="_blank" href="<?php echo e($header->youtube ?? '#'); ?>"
                          aria-label="Youtube"><i class="fab fa-youtube"></i></a></li>
                  <li><a target="_blank" href="<?php echo e($header->whatsapp ?? '#'); ?>"
                          aria-label="Whatsapp"><i class="fab fa-whatsapp"></i></a>
                  </li>
                </ul>
              </div><!-- Footer social end -->
            </div><!-- Col end -->

            <div class="col-lg-4 col-md-6 footer-widget mt-5 mt-md-0">
              <h3 class="widget-title">Contact</h3>
              <div class="working-hours">
                <?php echo e($header->address ?? ''); ?>

                <br><br> Call Now: <span class="text-right"><?php echo e($header->phone ?? ''); ?></span>
                <br> Send Email: <span class="text-right"><?php echo e($header->email ?? ''); ?></span>
                <br>
                <br>
                <ul class="list-arrow">
                  <li><span class="text-right">
                      <a style="hover:#FFB600;" class="link" target="_blank" href="http://stonytrack.com:2095/">Web Mail
                        URL Link: stonytrack.com/webmail</a></li>
                </ul></span>
              </div>
            </div><!-- Col end -->

            <div class="col-lg-3 col-md-6 mt-5 mt-lg-0 footer-widget">
              <h3 class="widget-title">Services</h3>
              <ul class="list-arrow">
                <li><a href="<?php echo e($footer->s_menu_url1 ?? ''); ?>">Fire Detection & Alarm System</a></li>
                <li><a href="<?php echo e($footer->s_menu_url2 ?? ''); ?>">Fire Protection System</a></li>
                <li><a href="<?php echo e($footer->s_menu_url3 ?? ''); ?>">Fire Safety Consultancy</a></li>
                <li><a href="<?php echo e($footer->s_menu_url4 ?? ''); ?>">HVAC System</a></li>
                <li><a href="<?php echo e($footer->s_menu_url5 ?? ''); ?>">Electrical Sub-Station</a></li>
                <li><a href="<?php echo e($footer->s_menu_url6 ?? ''); ?>">Electrical Generator</a></li>
              </ul>
            </div><!-- Col end -->
          </div><!-- Row end -->
        </div><!-- Container end -->
      </div><!-- Footer main end -->

      <div class="copyright">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-6">
              <div class="copyright-info">
                <span>Copyright &copy;
                  <script>
                    document.write(new Date().getFullYear())
                  </script>, <?php echo e($footer->copyright_txt ?? ''); ?> <a href="<?php echo e(url('/')); ?>">Stony Track</a>
                </span>
              </div>
            </div>

            <div class="col-md-6">
              <div class="footer-menu text-center text-md-right">
                <ul class="list-unstyled">
                  <li><a href="<?php echo e($footer->foo_menu_url1 ?? ''); ?>">About</a></li>
                  <li><a href="<?php echo e($footer->foo_menu_url2 ?? ''); ?>">Our Gallery</a></li>
                  <!-- <li><a href="faq.html">Faq</a></li> -->
                  <li><a href="<?php echo e($footer->foo_menu_url3 ?? ''); ?>">Terms & Conditions</a></li>
                  <li><a href="<?php echo e($footer->foo_menu_url4 ?? ''); ?>">Privacy & Policy</a></li>
                </ul>
              </div>
            </div>
          </div><!-- Row end -->

          <div id="back-to-top" data-spy="affix" data-offset-top="10" class="back-to-top position-fixed">
            <button class="btn btn-primary" title="Back to Top">
              <i class="fa fa-angle-double-up"></i>
            </button>
          </div>

        </div><!-- Container end -->
      </div><!-- Copyright end -->
    </footer><!-- Footer end -->


    <!-- Javascript Files
  ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="<?php echo e(asset('assets/plugins/jQuery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap jQuery -->
    <script src="<?php echo e(asset('assets/plugins/bootstrap/bootstrap.min.js')); ?>" defer></script>
    <!-- Slick Carousel -->
    <script src="<?php echo e(asset('assets/plugins/slick/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/slick/slick-animation.min.js')); ?>"></script>
    <!-- Color box -->
    <script src="<?php echo e(asset('assets/plugins/colorbox/jquery.colorbox.js')); ?>"></script>
    <!-- shuffle -->
    <script src="<?php echo e(asset('assets/plugins/shuffle/shuffle.min.js')); ?>" defer></script>


    <!-- Google Map API Key-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU" defer></script>
    <!-- Google Map Plugin-->
    <script src="<?php echo e(asset('assets/plugins/google-map/map.js')); ?>" defer></script>

    <!-- Template custom -->
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

  </div><!-- Body inner end -->

  <script>
    $(document).ready(function () {
      $('.customer-logos').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 4
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 3
          }
        }]
      });
    });
    $(document).ready(function () {
      $('.customer-brands').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 1
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 1
          }
        }]
      });
    });
  </script>

  <script>
    $(document).ready(function () {
      $('.customer-standc').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 1
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 1
          }
        }]
      });
    });
  </script>

  <script>
    $(document).ready(function () {
      $('.customer-brands2').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 2
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 1
          }
        }]
      });
    });
    $(document).ready(function () {
      $('.customer-standc2').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 1
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 1
          }
        }]
      });
    });
    $(document).ready(function () {
      $('.customer-brands3').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 2
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 1
          }
        }]
      });
    });
    $(document).ready(function () {
      $('.customer-standc3').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 2
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 1
          }
        }]
      });
    });
    $(document).ready(function () {
      $('.customer-brands4').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 2
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 1
          }
        }]
      });
    });

    $(document).ready(function () {
      $('.customer-standc4').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 2
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 1
          }
        }]
      });
    });
  </script>

</body>

</html><?php /**PATH /home/stonytra/public_html/resources/views/layout/frontend/footer.blade.php ENDPATH**/ ?>