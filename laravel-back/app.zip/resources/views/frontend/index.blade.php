@include('layout.frontend.header')

    @include('frontend.home')
      
@include('layout.frontend.footer')