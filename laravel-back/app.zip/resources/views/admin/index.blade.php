@include('layout.admin.header')

    @include('admin.dashboard')
      
@include('layout.admin.footer')