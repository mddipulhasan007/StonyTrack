-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 31, 2023 at 02:58 PM
-- Server version: 5.7.37-log
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stonytra_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_contents`
--

CREATE TABLE `about_contents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `left_about_txt` text COLLATE utf8mb4_unicode_ci,
  `read_more_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read_more_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bottom_text_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bottom_text_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bottom_text_3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bottom_text_4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `right_values_txt` text COLLATE utf8mb4_unicode_ci,
  `safety_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `safety_txt` text COLLATE utf8mb4_unicode_ci,
  `service_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_txt` text COLLATE utf8mb4_unicode_ci,
  `integrity_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `integrity_txt` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `about_contents`
--

INSERT INTO `about_contents` (`id`, `left_about_txt`, `read_more_text`, `read_more_url`, `bottom_text_1`, `bottom_text_2`, `bottom_text_3`, `bottom_text_4`, `right_values_txt`, `safety_text`, `safety_txt`, `service_text`, `service_txt`, `integrity_text`, `integrity_txt`, `created_at`, `updated_at`) VALUES
(1, '<h2 class=\"into-title\">ABOUT US</h2>\r\n<h3 class=\"into-sub-title\">WE DELIVER PROJECTS</h3>\r\n<p>Stony Track providers of MEP Engineering Products and Services (Fire Protection System and HVAC System, Electrical Sub-station, Generator, Plumbing Services and Others related to MEP).</p>', 'Read More', '/about', 'WE\'VE REPUTION FOR EXCELLENCE', 'WE\'VE REPUTION FOR EXCELLENCE WE BUILD PARTNERSHIPS', 'GUIDED BY COMMITMENT', 'A TEAM OF PROFESSIONALS', '<h3 class=\"into-sub-title\">OUR VALUES</h3>\r\n<p>We will serve all our customers: owners, clients, contractors, suppliers and all A/E team members. We will listen to their needs and respond appropriately.</p>', 'SAFETY', '<p>First and foremost, always. It&rsquo;s in our hands. Safety is the cornerstone of Austin&rsquo;s business and no work is ever too urgent or too important that we cannot take time to do it safely. Safety is a way of life; a choice that becomes an instinct.</p>', 'SERVICE', '<p>We will serve all our customers: owners, clients, contractors, suppliers and all A/E team members. We will listen to their needs and respond appropriately. We will demonstrate humility to them. We will listen more than we talk. We will be polite to everyone. We will show mutual respect for all we contact. We will work to build each person&rsquo;s self-esteem.</p>', 'INTEGRITY', '<p>Errors can be forgiven; breaking our word won&rsquo;t be accepted. We will not tolerate any breach of integrity. We will face it, repent, and make amends, if necessary, and correct the root cause. We will strictly follow the engineering code of ethics in all our professional dealings.</p>', '2023-12-11 21:16:30', '2023-12-25 12:12:18');

-- --------------------------------------------------------

--
-- Table structure for table `about_pages`
--

CREATE TABLE `about_pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bdcmb_banner_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bdcmb_show_hide` text COLLATE utf8mb4_unicode_ci,
  `teams_show_hide` text COLLATE utf8mb4_unicode_ci,
  `left_about_txt` text COLLATE utf8mb4_unicode_ci,
  `total_projects_count` text COLLATE utf8mb4_unicode_ci,
  `staff_members_count` text COLLATE utf8mb4_unicode_ci,
  `running_project_count` text COLLATE utf8mb4_unicode_ci,
  `dist_exp_count` text COLLATE utf8mb4_unicode_ci,
  `about_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `integrity_txt` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `about_pages`
--

INSERT INTO `about_pages` (`id`, `bdcmb_banner_img`, `bdcmb_show_hide`, `teams_show_hide`, `left_about_txt`, `total_projects_count`, `staff_members_count`, `running_project_count`, `dist_exp_count`, `about_img`, `integrity_txt`, `created_at`, `updated_at`) VALUES
(1, 'uploads/DpZs0whPc9G5G6boHXn4m00K4fOu7trWzFd3CCoK.jpg', 'block', 'block', '<h3 class=\"column-title\">WHO WE ARE</h3>\r\n<p>Stony Track providers of MEP Engineering Products and Services (Fire Protection System and HVAC System, Electrical Sub-station, Generator, Plumbing Services and Others related to MEP).</p>\r\n<blockquote>\r\n<p>We will serve all our customers: owners, clients, contractors, suppliers and all A/E team members. We will listen to their needs and respond appropriately.</p>\r\n</blockquote>\r\n<h4>SAFETY</h4>\r\n<p>First and foremost, always. It&rsquo;s in our hands. Safety is the cornerstone of Austin&rsquo;s business and no work is ever too urgent or too important that we cannot take time to do it safely. Safety is a way of life; a choice that becomes an instinct.</p>\r\n<h4>SERVICE</h4>\r\n<p>We will serve all our customers: owners, clients, contractors, suppliers and all A/E team members. We will listen to their needs and respond appropriately. We will demonstrate humility to them. We will listen more than we talk. We will be polite to everyone. We will show mutual respect for all we contact. We will work to build each person&rsquo;s self-esteem.</p>', '100', '50', '5', '10', 'uploads/TJoJ64zXoaOO2Cuyrf2H0W37fwyP1qfJh471x8NO.jpg', '<h4>INTEGRITY</h4>\r\n<p>Errors can be forgiven; breaking our word won&rsquo;t be accepted. We will not tolerate any breach of integrity. We will face it, repent, and make amends, if necessary, and correct the root cause. We will strictly follow the engineering code of ethics in all our professional dealings.</p>', '2023-12-30 01:40:20', '2023-12-30 01:44:37');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `logo`, `created_at`, `updated_at`) VALUES
(5, 'brands/HFN6u1Zo1pkMCLT4076NjGv2jCYFvgGVLoxYHr3t.png', '2023-11-19 02:07:43', '2023-11-19 02:07:43'),
(6, 'brands/eD8RxqjGn3SnBRyPmfN4ViVhgdKeOqA3qZA901cH.png', '2023-11-19 02:08:01', '2023-11-19 02:08:01'),
(7, 'brands/7NOOoHFMidsWdR7sj6zWAyijJcm8p4LiKgeRjaC0.png', '2023-11-19 02:08:09', '2023-11-19 02:08:09'),
(8, 'brands/MtW3ONXUZ4LqgEXFr5C4e6v1HNsnzD2XjerXIElJ.png', '2023-11-19 02:08:17', '2023-11-19 02:08:17'),
(9, 'brands/R4K1afz9RFQ8z50vV3ncfLk2IpwDEN7KgZ9vTQku.png', '2023-11-19 02:08:24', '2023-11-19 02:08:24'),
(10, 'brands/eGWT3nu8IjGLhyFVS7eaYRZBhCRN4u3EQrxMru4k.png', '2023-11-19 02:09:51', '2023-11-19 02:09:51'),
(11, 'brands/KudM8sj9tJ1Uwt643043O28L8IgdDeVwQ3UkGbze.png', '2023-11-19 02:10:04', '2023-11-19 02:10:04'),
(12, 'brands/txPE1FtAacU46zDLenSqSoY5qjVpMWlY6hwEo5NY.png', '2023-11-19 02:10:13', '2023-11-19 02:10:13'),
(13, 'brands/FSuImTE5gapxuzWWKIvURs7Mq6xo8Jm38qkxfXYt.png', '2023-11-19 02:10:20', '2023-11-19 02:10:20'),
(14, 'brands/X1udBz2R4w22i6NlB7JaTJUIS2gFjTupJxLStdnJ.png', '2023-11-19 02:10:28', '2023-11-19 02:10:28'),
(15, 'brands/b24ve0m4DPAdeJONtSP8hb7gBle9n0j2MM2CrqaX.png', '2023-11-19 02:10:34', '2023-11-19 02:10:34'),
(16, 'brands/PW7UDN6HxSEgeKLJeDfCdTxMO90tgBKOGLkF4lX8.png', '2023-11-19 02:10:39', '2023-11-19 02:10:39'),
(17, 'brands/fYiJehhAHKX5gYkklVWr6x157In0qYDKbT1wkdPs.png', '2023-11-19 02:10:46', '2023-11-19 02:10:46'),
(18, 'brands/nUIfqXYkY4XvQzkVOeawVFoc0UoC45hPnzYRibzW.png', '2023-11-19 02:10:53', '2023-11-19 02:10:53'),
(19, 'brands/N5eFvf5QFYMsy9GfXCYjjsCZVImLAc8dXesRPhl8.png', '2023-11-19 02:11:02', '2023-11-19 02:11:02'),
(20, 'brands/fhWadIG1My0zWhNyhVDBCU3YqbxsBmx5fYJg7nCw.png', '2023-11-19 02:11:10', '2023-11-19 02:11:10'),
(21, 'brands/MTwccMMGpVUZoZyCDVTHukSx25z4iZs2VciPtU3L.png', '2023-11-19 02:11:18', '2023-11-19 02:11:18'),
(22, 'brands/QWC0AjdX92UQgjlv5ILBkwHS8uhKKOuq5CDkso2z.png', '2023-11-19 02:11:25', '2023-11-19 02:11:25');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cat_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `cat_image`, `created_at`, `updated_at`) VALUES
(3, 'FIRE DETECTION & ALARM SYSTEM', 'fire-detection-alarm-system', 'categories/ExSWK7pPoiWxDMZ3r8SAisSnNZ6mS5nfRrFoW2Fj.jpg', '2023-12-30 04:36:13', '2023-12-30 04:36:13'),
(4, 'FIRE PROTECTION SYSTEM', 'fire-protection-system', 'categories/UQBv60iLzZ8RgItPDgF0saoup7rPOCWIx7WgTZZw.jpg', '2023-12-30 04:36:45', '2023-12-30 04:36:45'),
(5, 'FIRE SAFETY CONSULTANCY', 'fire-safety-consultancy', 'categories/sSgIEIDsKeaGJgCjvy6MYMhPfwxSh7I79quZZg1v.jpg', '2023-12-30 04:36:59', '2023-12-30 04:36:59'),
(6, 'HVAC SYSTEM', 'hvac-system', 'categories/Kqt4JdUgOdGR6PX7Dka4BzoTJu6GHSejGb6FY5lG.jpg', '2023-12-30 04:37:12', '2023-12-30 04:37:12'),
(7, 'ELECTRICAL SUB-STATION', 'electrical-sub-station', 'categories/rkazFcMHIkV5HRVMv2to0lS0ZfIpfjq1cyU05ilp.jpg', '2023-12-30 04:37:23', '2023-12-30 04:37:23'),
(8, 'ELECTRICAL GENERATOR', 'electrical-generator', 'categories/6w0EAHaanLaIZCbdNPnU6pqiSub3qVRbYn5cAysk.jpg', '2023-12-30 04:37:34', '2023-12-30 04:37:34'),
(9, 'PLUMBING SERVICES', 'plumbing-services', 'categories/k07rQ81IsNi2xfYtBmKaSF7wr5MErTBylF5Qd5Z4.jpg', '2023-12-30 04:37:44', '2023-12-30 04:37:44'),
(10, 'ESCALATOR & ELEVATOR (LIFT)', 'escalator-elevator-lift', 'categories/NHS8LpMgFJvIaOlrTwNIWIc52mtn7NybcgXSVC2c.jpg', '2023-12-30 04:37:55', '2023-12-30 04:37:55'),
(11, 'SOLAR POWER SYSTEM', 'solar-power-system', 'categories/pM04jmBpiObusMEbKxdjlt7yo4JwMhPeN1z4qjqz.jpg', '2023-12-30 04:38:05', '2023-12-30 04:38:05'),
(12, 'ELECTRONIC SECURITY & COMMUNICATION SYSTEMS', 'electronic-security-communication-systems', 'categories/OL4QdHGi2aj5ILqlGpNXzF21Djc7ScdfD73BGVQw.jpg', '2023-12-30 04:38:15', '2023-12-30 04:38:15');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `message`, `created_at`, `updated_at`) VALUES
(1, 'Md Dipul Hasan', 'dipulhasanbd@gmail.com', 'Hosting Renew', 'message', '2023-11-26 04:27:24', '2023-11-26 04:27:24'),
(2, 'Md Dipul Hasan', 'dipulhasanbd@gmail.com', 'Xtapowereng Hosting Renew', 'hello', '2023-11-26 04:31:28', '2023-11-26 04:31:28'),
(3, 'Md Dipul Hasan', 'dipulhasanbd@gmail.com', 'Xtapowereng Hosting Renew', 'test message', '2023-11-26 04:33:41', '2023-11-26 04:33:41'),
(4, 'Md Rakibul Islam', 'shohelislam@yahoo.com', 'Civid Vaccine Apply Issue', 'messge', '2023-12-09 10:15:57', '2023-12-09 10:15:57'),
(5, 'Md Rakibul Islam', 'shohelislam@yahoo.com', 'Your sms not working in my website when any user login', 'message', '2023-12-09 10:27:33', '2023-12-09 10:27:33'),
(6, 'Md Dipul Hasan', 'dipulhasanbd@gmail.com', 'Hosting Renew 2', 'message', '2023-12-09 10:28:44', '2023-12-09 10:28:44'),
(7, 'Md Rezaul Karim', 'xtrapowereng@gmail.com', 'Hosting Renew 555', 'message', '2023-12-09 10:29:54', '2023-12-09 10:29:54'),
(8, 'Md Dipul Hasan', 'dipulhasanbd@gmail.com', 'Your sms not working i ddd', 'message', '2023-12-09 10:39:40', '2023-12-09 10:39:40'),
(9, 'Md Rezaul Karim', 'xtrapowereng@gmail.com', 'ddddddddddddddd', 'message', '2023-12-09 10:42:09', '2023-12-09 10:42:09'),
(10, 'Md Rezaul Karim', 'xtrapowereng@gmail.com', 'Xtapowereng Hosting Renew 22', 'message dddddddddd', '2023-12-09 12:42:11', '2023-12-09 12:42:11'),
(11, 'Md Rezaul Karim', 'xtrapowereng@gmail.com', 'Xtapowereng Hosting Renew ddd', 'dddddddddddddd', '2023-12-09 12:44:54', '2023-12-09 12:44:54'),
(12, 'Md Dipul Hasan', 'dipulhasanbd@gmail.com', 'Hosting Renew', 'ffffffffffffffffffffffffff', '2023-12-09 12:45:50', '2023-12-09 12:45:50'),
(13, 'Md Rakibul Islam', 'shohelislam@yahoo.com', 'fffffffffff', 'ffffffffffff', '2023-12-09 12:56:51', '2023-12-09 12:56:51'),
(14, 'Md Rezaul Karim', 'xtrapowereng@gmail.com', 'dddddddd', 'dddddddddd', '2023-12-09 12:57:39', '2023-12-09 12:57:39'),
(15, 'Md Dipul Hasan', 'dipulhasanbd@gmail.com', 'ddddd', 'dddddd', '2023-12-09 13:04:56', '2023-12-09 13:04:56'),
(16, 'Md Rezaul Karim', 'xtrapowereng@gmail.com', 'dsfsd', 'fsdfgsd', '2023-12-09 13:14:51', '2023-12-09 13:14:51'),
(17, 'Md Dipul Hasan', 'dipulhasanbd@gmail.com', 'dd', 'dd', '2023-12-09 13:15:28', '2023-12-09 13:15:28'),
(18, 'Md Rezaul Karim', 'xtrapowereng@gmail.com', 'dd', 'dd', '2023-12-09 13:16:30', '2023-12-09 13:16:30'),
(19, 'Md Dipul Hasan', 'dipulhasanbd@gmail.com', 'Xtapowereng Hosting Renew5', 'message', '2023-12-10 00:49:43', '2023-12-10 00:49:43');

-- --------------------------------------------------------

--
-- Table structure for table `email_settings`
--

CREATE TABLE `email_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `footers`
--

CREATE TABLE `footers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about_txt` text COLLATE utf8mb4_unicode_ci,
  `s_menu_url1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_menu_url2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_menu_url3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_menu_url4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_menu_url5` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_menu_url6` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright_txt` text COLLATE utf8mb4_unicode_ci,
  `foo_menu_url1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foo_menu_url2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foo_menu_url3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foo_menu_url4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `footers`
--

INSERT INTO `footers` (`id`, `logo`, `about_txt`, `s_menu_url1`, `s_menu_url2`, `s_menu_url3`, `s_menu_url4`, `s_menu_url5`, `s_menu_url6`, `copyright_txt`, `foo_menu_url1`, `foo_menu_url2`, `foo_menu_url3`, `foo_menu_url4`, `created_at`, `updated_at`) VALUES
(1, 'uploads/oxJ0z7ImrVptpXnLqCbTGA0uSu5l6s71vaLWqMrm.png', '<p>Stony Track providers of MEP Engineering Products and Services (Fire Protection System and HVAC System, Electrical Sub-station, Generator, Plumbing Services and Others related to MEP).</p>', 'http://stonytrack.com/fire-detection-alarm', 'http://stonytrack.com/fire-protection-system', 'http://stonytrack.com/', 'http://stonytrack.com/', 'http://stonytrack.com/', 'http://stonytrack.com/', 'Designed & Developed by', 'http://stonytrack.com/about', 'http://stonytrack.com/projects', 'http://stonytrack.com/', 'http://stonytrack.com/', '2023-11-18 22:22:51', '2023-12-09 09:44:24');

-- --------------------------------------------------------

--
-- Table structure for table `headers`
--

CREATE TABLE `headers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `headers`
--

INSERT INTO `headers` (`id`, `logo`, `created_at`, `updated_at`, `email`, `phone`, `address`, `facebook`, `linkedin`, `youtube`, `whatsapp`, `contact_email`) VALUES
(1, 'uploads/MQmtugJePGZgg533JTSBYhjLVJ5mIXy6ibCxcLej.png', '2023-11-18 12:07:06', '2023-12-09 12:22:57', 'info@stonytrack.com', '01997719933', '75-76, (1ST Floor), Janata Housing, Ring Road Adabor, Dhaka-1207, Bangladesh', 'https://www.facebook.com/profile.php?id=61551020260743', 'https://www.linkedin.com/company/96966204', 'https://www.youtube.com/channel/UCz6jebY3EaFIYseXXapIymA', 'https://wa.me/8801997719933', 'contact@stonytrack.com');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `name`, `slug`, `parent_id`, `created_at`, `updated_at`) VALUES
(34, 'HOME', 'HOME', NULL, '2023-11-26 05:19:21', '2023-11-26 05:19:21'),
(35, 'ABOUT US', 'ABOUT US', NULL, '2023-11-26 05:19:21', '2023-11-26 05:19:21'),
(36, 'PRODUCTS & SERVICES', 'PRODUCTS & SERVICES', NULL, '2023-11-26 05:19:21', '2023-11-26 05:19:21'),
(37, 'PROJECTS', 'PROJECTS', NULL, '2023-11-26 05:19:21', '2023-11-26 05:19:21'),
(38, 'MEDIA & NEWS', 'media-news', NULL, '2023-11-26 05:19:21', '2023-11-26 05:19:21'),
(39, 'CONTACT US', 'CONTACT US', NULL, '2023-11-26 05:19:21', '2023-11-26 05:19:21');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(13, '2014_10_12_000000_create_users_table', 1),
(14, '2014_10_12_100000_create_password_resets_table', 1),
(15, '2019_08_19_000000_create_failed_jobs_table', 1),
(16, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(17, '2023_11_12_041645_create_headers_table', 1),
(18, '2023_11_12_062650_add_additional_fields_to_headers_table', 1),
(19, '2023_11_18_144417_create_sliders_table', 1),
(20, '2023_11_19_041243_create_footers_table', 2),
(21, '2023_11_19_063520_create_brands_table', 3),
(22, '2023_11_25_194420_create_menu_items_table', 4),
(23, '2023_11_26_101711_create_contacts_table', 5),
(48, '2014_10_12_000000_create_users_table', 1),
(49, '2014_10_12_100000_create_password_resets_table', 1),
(50, '2019_08_19_000000_create_failed_jobs_table', 1),
(51, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(52, '2023_11_12_041645_create_headers_table', 1),
(53, '2023_11_12_062650_add_additional_fields_to_headers_table', 1),
(54, '2023_11_18_144417_create_sliders_table', 1),
(55, '2023_11_19_041243_create_footers_table', 1),
(56, '2023_11_19_063520_create_brands_table', 1),
(57, '2023_11_25_194420_create_menu_items_table', 1),
(58, '2023_11_26_101711_create_contacts_table', 1),
(63, '2023_12_09_170517_create_email_settings_table', 6),
(65, '2023_12_12_030351_create_about_contents_table', 7),
(66, '2023_12_13_011709_create_service_contents_table', 8),
(74, '2023_12_09_071829_create_categories_table', 10),
(75, '2023_12_09_072712_create_services_table', 10),
(79, '2023_12_14_012756_create_about_pages_table', 11),
(80, '2023_12_25_193143_create_teams_table', 11),
(81, '2023_12_31_044934_create_projectcategories_table', 12),
(83, '2023_12_31_045135_create_projects_table', 13);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projectcategories`
--

CREATE TABLE `projectcategories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cat_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projectcategories`
--

INSERT INTO `projectcategories` (`id`, `name`, `slug`, `cat_image`, `created_at`, `updated_at`) VALUES
(2, 'RECENT PROJECTS', 'recent-projects', 'projectcategories/zx8JxxHhFrEG0VH1a82p8tDYgZGCes7nRaAf2jPh.jpg', '2023-12-30 23:14:18', '2023-12-30 23:14:18'),
(3, 'INDUSTRIAL / MANUFACTRING', 'industrial-manufactring', 'projectcategories/72dlzvzP9CifhF5dUD8Zh9ELfCEroyXRFdDJ5r3D.jpg', '2023-12-30 23:14:43', '2023-12-30 23:14:43'),
(4, 'COMMERCIAL', 'commercial', 'projectcategories/GZspT0ypdPZi0KxpYDtzFVdQAiAGeVGH1bYzhNNM.jpg', '2023-12-30 23:14:58', '2023-12-30 23:14:58'),
(5, 'RESIDENTIAL', 'residential', 'projectcategories/7XDayrCNIwxHrjwW1PWEjhzx9RlepTcYe3lRDbWm.jpg', '2023-12-30 23:15:08', '2023-12-30 23:15:08'),
(6, 'OTHER', 'other', 'projectcategories/DQz2ag4RZkam9H45mblfRtP9pqxIwMe9Rlb2RyGw.jpg', '2023-12-30 23:15:15', '2023-12-31 00:39:11');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdf_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feature_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `category_id`, `title`, `slug`, `content`, `pdf_url`, `feature_image`, `created_at`, `updated_at`) VALUES
(2, 2, 'WE JUST COMPLETED BRITISH AMERICAN TOBACO BANGLADESH (BATB) 2', 'we-just-completed-british-american-tobaco-bangladesh-batb-2', '<h5 class=\"column-title mb-1\">Detection &amp; Alarm Products:&nbsp;<span class=\"small-fs\">Addressable &amp; Conventional</span></h5>\r\n<p>A full range of addressable and conventional ﬁre detection systems, beam detection, aspiration system, gas detection systems, extinguishing aerosol system, ﬂame detectors and power supply units. We apply the latest science and Engineering code and standard of NFPA.</p>', NULL, 'projects/9TtnTPabxwTz6Ud8CPB2uHlCic67S5ekWbuggHUs.jpg', '2023-12-30 23:31:50', '2023-12-31 01:31:47'),
(3, 3, 'ONGOING PROJECT IS AIRTRAFIC CONTROL TOWER FIRE DETECTION, HYDRANT', 'ongoing-project-is-airtrafic-control-tower-fire-detection-hydrant', '<p>Content here...</p>', NULL, 'projects/iVQJXxZMWjHS2RWprQrLYB6fqUBUwiuMbNZYZ45T.jpg', '2023-12-31 01:28:28', '2023-12-31 01:28:28'),
(4, 4, 'HAVE DONE PN COMPOSIT LTD.', 'have-done-pn-composit-ltd', '<p>Content here...</p>', NULL, 'projects/BKIjOul24oIceArbCdYXV617KQSXuDdpPVCrgUAT.jpg', '2023-12-31 01:29:08', '2023-12-31 01:29:08'),
(5, 5, 'NARRIOT HEADQUARTERS', 'narriot-headquarters', '<p>Content here...</p>', NULL, 'projects/1FWmQgo8CJVLcXCv0cAdYunleizYTo7OQQrzKweV.jpg', '2023-12-31 01:29:28', '2023-12-31 01:29:28'),
(6, 6, 'KALAS METRORAIL', 'kalas-metrorail', '<p>Content here...</p>', NULL, 'projects/ykH7NuJBn7lPRaL0VNxrRs2ZsvbpWMgdV0cM4u57.jpg', '2023-12-31 01:30:57', '2023-12-31 01:30:57');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pdf_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `slug`, `content`, `feature_image`, `pdf_url`, `category_id`, `created_at`, `updated_at`) VALUES
(4, 'FIRE DETECTION & ALARM SYSTEM', 'fire-detection-alarm-system', '<h5 class=\"column-title mb-1\">Detection &amp; Alarm Products:&nbsp;<span class=\"small-fs\">Addressable &amp; Conventional</span></h5>\r\n<p>A full range of addressable and conventional ﬁre detection systems, beam detection, aspiration system, gas detection systems, extinguishing aerosol system, ﬂame detectors and power supply units. We apply the latest science and Engineering code and standard of NFPA.</p>', 'services/AvXcV6qz6cDq5V4gY4NtsbPpq4B2TpKJMxZDFjc9.jpg', 'https://stonytrack.com/pdfurl', 3, '2023-12-31 01:05:26', '2023-12-31 01:05:26'),
(5, 'ACTIVE FIRE PROTECTION SYSTEM NEW', 'active-fire-protection-system-new', '<h5 class=\"column-title mb-1\">Active Fire Protection System:</h5>\r\n<p>Fire Sprinkler System<br>Water Mist System<br>Fire Suppression (Clean Agent-NOVEC1230 &amp; FM200)<br>Fire Suppression Aerosol System<br>Foam Deluge System<br>Oxygen reduction fire protection system</p>', 'services/ea2dxjRW6REyBK3nujb909vtjxI2d891cyqSXI11.jpg', NULL, 4, '2023-12-31 01:05:52', '2023-12-31 01:06:09'),
(6, 'ACTIVE FIRE PROTECTION SYSTEM:', 'active-fire-protection-system', '<h5 class=\"column-title mb-1\">Active Fire Protection System:</h5>\r\n<p>Fire Sprinkler System<br>Water Mist System<br>Fire Suppression (Clean Agent-NOVEC1230 &amp; FM200)<br>Fire Suppression Aerosol System<br>Foam Deluge System<br>Oxygen reduction fire protection system</p>', 'services/PpdXBMQ0KBHPJlrVH6vooctb5XiQCkOokUH5yWhq.jpg', NULL, 4, '2023-12-31 01:06:36', '2023-12-31 01:06:36'),
(7, 'MANUAL FIRE PROTECTION SYSTEM:', 'manual-fire-protection-system', '<h5 class=\"column-title mb-1\">Manual Fire Protection System:&nbsp;<span class=\"small-fs\">Fire Standpipe &amp; Hydrant System</span></h5>\r\n<p>Stonytrack supplied, installed, serve and maintained of all types of fire protection solution for passive, active and manual fire protection as per NFPA, BNBC and IFC.</p>', 'services/BwqCHJVhpakyAZhOJCfmdvH6G3yU7LEMsa3I75sy.jpg', NULL, 4, '2023-12-31 01:07:05', '2023-12-31 01:07:05');

-- --------------------------------------------------------

--
-- Table structure for table `service_contents`
--

CREATE TABLE `service_contents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `fire_protect_system` text COLLATE utf8mb4_unicode_ci,
  `hvac_system` text COLLATE utf8mb4_unicode_ci,
  `electrical_solu` text COLLATE utf8mb4_unicode_ci,
  `middle_title_txt` text COLLATE utf8mb4_unicode_ci,
  `service_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plumbing_service` text COLLATE utf8mb4_unicode_ci,
  `elevator_escalator` text COLLATE utf8mb4_unicode_ci,
  `safety_consult` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_contents`
--

INSERT INTO `service_contents` (`id`, `fire_protect_system`, `hvac_system`, `electrical_solu`, `middle_title_txt`, `service_img`, `plumbing_service`, `elevator_escalator`, `safety_consult`, `created_at`, `updated_at`) VALUES
(1, '<h3 class=\"service-box-title\"><a href=\"../projects\">FIRE PROTECTION SYSTEM</a></h3>\r\n<p>We live in a technology-driven world. In recent years, the building fire protection&hellip;</p>', '<h3 class=\"service-box-title\"><a href=\"../projects\">HVAC SYSTEM</a></h3>\r\n<p>Our dedicated HVAC Services team is here for you &hellip;</p>', '<h3 class=\"service-box-title\"><a href=\"../projects\">ELECTRICAL SOLUTIONS</a></h3>\r\n<p>Electrical Services is fully committed to providing our clients with energy efficient &hellip;</p>', '<h2 class=\"section-title\">WE ARE SPECIALISTS IN</h2>\n<h3 class=\"section-sub-title\">WHAT WE DO</h3>', 'uploads/wrlnqnDjAp2ZoSGVBjGtsAXET5ZB8Qy7wJ2Irtpw.jpg', '<h3 class=\"service-box-title\"><a href=\"../projects\">PLUMBING SERVICES</a></h3>\r\n<p>Our plumbing engineers design systems with your &ldquo;whole building&rdquo; &hellip;</p>', '<h3 class=\"service-box-title\"><a href=\"../projects\">ELEVATOR &amp; ESCALATOR</a></h3>\r\n<p>Stonytrack supply and provide maintenance services of Elevator and Escalator in the Bangladesh market&hellip;</p>', '<h3 class=\"service-box-title\"><a href=\"../projects\">SAFETY CONSULTANCY</a></h3>\r\n<p>Our safety consultants visit the workplaces and evaluate them for potential risks and hazards and derive a safety plan against people and property ...</p>', '2023-12-12 19:33:03', '2023-12-20 19:48:56');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caption_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `main_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `services_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `image_path`, `caption_title`, `main_title`, `contact_url`, `services_url`, `created_at`, `updated_at`) VALUES
(1, 'slider_images/THWGjwzowPQMNZ8mrKRxEz8rOaxzFTapp79NOvrf.jpg', 'Life & Fire Safety Professiona', 'FIRE PROTECITON SYSTE', 'http://stonytrack.com/contact', 'http://stonytrack.com/contact', '2023-11-18 10:40:00', '2023-11-18 10:57:26'),
(2, 'slider_images/6pc6MuZ6YgmL95iNhTROUHz1dD3YPIMivM4iJWm4.jpg', 'Meet our engineers 2', 'ELECTRICAL SOLUTION', 'http://stonytrack.com/contac', 'http://stonytrack.com/contac', '2023-11-18 10:40:00', '2023-12-13 20:49:10'),
(3, 'slider_images/GJ5WOXczVXpFbaoh01ggAx4uFJCJDBlSCtyYU9ch.jpg', 'Your choice is healthy environment', 'HVAC SYSTEM', 'http://stonytrack.com/contact', 'http://stonytrack.com/contact', '2023-11-18 10:40:00', '2023-11-19 02:14:58'),
(4, 'slider_images/wxSpV0NSyAbzgxwYIIdPXtF6gho3icZ3tP3qf5tl.jpg', 'Your total electrical mechanical and plumbing service provider', 'MEP ENGINEERING SERVICES', 'http://stonytrack.com/contact', 'http://stonytrack.com/contact', '2023-11-18 10:40:00', '2023-11-19 02:14:58');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualification` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `qualification`, `profile_image`, `short_content`, `created_at`, `updated_at`) VALUES
(1, 'Md Monowarul Islam', 'Chief Operating Officer', 'teams/emwG9RPaBCYzS1X7U8LpLsRloqURv3JS16MSDPnx.jpg', '<p>Content here...</p>', '2023-12-31 02:06:42', '2023-12-31 02:06:42'),
(2, 'MizanurRahman', 'Site Supervisor', 'teams/LMqrmSnZR4UewnCZUfKj2IrQ8FsykmMDBaVxpT95.jpg', '<p>Content here...</p>', '2023-12-31 02:24:39', '2023-12-31 02:24:39');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Md Monowarul Islam', 'admin@stonytrack.com', NULL, '$2y$10$iZS2KFkZ3RXispzxXPZTgeg1oIBNMNPX8NyAFFqHXvhS6cAQqORFi', NULL, '2023-11-18 10:30:54', '2023-11-18 10:30:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_contents`
--
ALTER TABLE `about_contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `about_pages`
--
ALTER TABLE `about_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_settings`
--
ALTER TABLE `email_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `footers`
--
ALTER TABLE `footers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `headers`
--
ALTER TABLE `headers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `projectcategories`
--
ALTER TABLE `projectcategories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `projectcategories_name_unique` (`name`),
  ADD UNIQUE KEY `projectcategories_slug_unique` (`slug`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `projects_slug_unique` (`slug`),
  ADD KEY `projects_category_id_foreign` (`category_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `services_slug_unique` (`slug`),
  ADD KEY `services_category_id_foreign` (`category_id`);

--
-- Indexes for table `service_contents`
--
ALTER TABLE `service_contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_contents`
--
ALTER TABLE `about_contents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `about_pages`
--
ALTER TABLE `about_pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `email_settings`
--
ALTER TABLE `email_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `footers`
--
ALTER TABLE `footers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `headers`
--
ALTER TABLE `headers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projectcategories`
--
ALTER TABLE `projectcategories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `service_contents`
--
ALTER TABLE `service_contents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `projectcategories` (`id`);

--
-- Constraints for table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
